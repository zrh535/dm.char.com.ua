package server;

import java.io.*;

import java.text.*;

public class Base64Encoder{

	private static final char[] Base64Chars={
		'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
		'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b',
		'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p',
		'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3',
		'4', '5', '6', '7', '8', '9', '+', '/', '='
	};


	public static final String toBase64String(byte[] bytes){
		return toBase64String(bytes, Base64Chars);
	}

	private static final String toBase64String(byte[] bytes, char[] chars){

		StringBuffer sb =new StringBuffer();
		int          len=bytes.length, i=0, ival;
		while(len>=3){
			ival=((int)bytes[i++]+256)&0xff;
			ival<<=8;
			ival+=((int)bytes[i++]+256)&0xff;
			ival<<=8;
			ival+=((int)bytes[i++]+256)&0xff;
			len -=3;
			sb.append(chars[(ival>>18)&63]);
			sb.append(chars[(ival>>12)&63]);
			sb.append(chars[(ival>>6)&63]);
			sb.append(chars[ival&63]);
		}
		switch(len){
			case 0 :	// No pads needed.
				break;
			case 1 :	// Two more output bytes and two pads.
				ival=((int)bytes[i++]+256)&0xff;
				ival<<=16;
				sb.append(chars[(ival>>18)&63]);
				sb.append(chars[(ival>>12)&63]);
				sb.append(chars[64]);
				sb.append(chars[64]);
				break;
			case 2 :	// Three more output bytes and one pad.
				ival=((int)bytes[i++]+256)&0xff;
				ival<<=8;
				ival+=((int)bytes[i]+256)&0xff;
				ival<<=8;
				sb.append(chars[(ival>>18)&63]);
				sb.append(chars[(ival>>12)&63]);
				sb.append(chars[(ival>>6)&63]);
				sb.append(chars[64]);
				break;
		}
		return new String(sb);
	}

	public static final byte[] fromBase64String(String s){

		try{
			StringCharacterIterator iter   =new StringCharacterIterator(s);
			ByteArrayOutputStream   bytestr=new ByteArrayOutputStream();
			DataOutputStream        outstr =new DataOutputStream(bytestr);
			char                    c;
			int                     d, i, group;
			int[]                   bgroup=new int[4];
			for(i=0, group=0, c=iter.first(); c!=CharacterIterator.DONE; c=iter.next()){
				if(c>='A'&&c<='Z'){
					d=c-'A';
				}else if(c>='a'&&c<='z'){
					d=c-'a'+26;
				}else if(c>='0'&&c<='9'){
					d=c-'0'+52;
				}else if(c=='+'){
					d=62;
				}else if(c=='/'){
					d=63;
				}else{
					break;
				}
				bgroup[i++]=d;
				if(i>=4){
					i    =0;
					group=((bgroup[0]&63)<<18)+((bgroup[1]&63)<<12)+((bgroup[2]&63)<<6)+(bgroup[3]&63);
					outstr.writeByte(((group>>16)&255));
					outstr.writeByte(((group>>8)&255));
					outstr.writeByte(group&255);
				}
			}
			switch(i){
				case 2 :
					// One output byte from two input bytes.
					group=((bgroup[0]&63)<<18)+((bgroup[1]&63)<<12);
					outstr.writeByte(((group>>16)&255));
					break;
				case 3 :
					// Two output bytes from three input bytes.
					group=((bgroup[0]&63)<<18)+((bgroup[1]&63)<<12)+((bgroup[2]&63)<<6);
					outstr.writeByte(((group>>16)&255));
					outstr.writeByte(((group>>8)&255));
					break;
				default :
					// Any other case, including correct 0, is treated as
					// end of data.
					break;
			}
			outstr.flush();
			return bytestr.toByteArray();
		}catch(IOException e) {}
		return null;
	}
}
