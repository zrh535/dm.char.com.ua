package server;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.net.Socket;
import java.net.InetAddress;
import java.util.StringTokenizer;

class RequestRunner implements Runnable{
	private Socket socket;

	public RequestRunner(Socket socket){
		this.socket=socket;
	}
	public void run(){
		String request=new String();
		String method="";
		String url="";
		String CR;
		Socket parentSock=null;
		byte bb[]=new byte[2048];
		int len=0;
		try{
			InputStream cis=socket.getInputStream(); //client input stream
			while( len>=0 ){
				try{
					len=cis.read(bb);
				}catch(Exception e){
					Logger.log(""+e);
					break;
				}
				if(len>0)request=request.concat(new String(bb,0,len));
				if(cis.available()<1)break;
			}
			//parse method and url
			try{
				StringTokenizer st=new StringTokenizer(request);
				method=st.nextToken();
				url=st.nextToken();
			}catch (Exception e){
				Logger.log("Exception: Wrong request?:\n"+request);
			}
			//substitute the readable address
			//go
			if(Restrict.isRestricted(url)){
				if(Server.logRestricted)Logger.log(socket.getInetAddress().getHostName(),"! "+method+" "+url,null);
				OutputStream cos=socket.getOutputStream(); //client input stream
				cos.write("HTTP/1.1 404 Not Found\r\nContent-Type: text/html\r\n\r\n".getBytes());
				cos.flush();
			}else{
				CR=getCR(request);
				request=hideHost(request,method,url,CR);
				
				if(Server.parentAuthorizationString!=null){
					if(request.indexOf(CR+"Proxy-Authorization:")<0){
						int i=request.indexOf(CR);
						if(i>0){
							request=request.substring(0,i)+
								CR+"Proxy-Authorization: "+Server.parentAuthorizationString+
								request.substring(i);
						}
					}else{
						Logger.log("Proxy-Authorization already exists in request");
					}
				}
				if(Server.logRequests)Logger.log(request);
				parentSock=new Socket(Server.parentHost,Server.parentPort);
				//send request
				OutputStream pos=parentSock.getOutputStream(); //parent output stream
				pos.write(request.getBytes());
				pos.flush();
				InputStream pis=parentSock.getInputStream(); //parent input stream
				OutputStream cos=socket.getOutputStream(); //client input stream
				if(method.toLowerCase().equals("connect")||request.toLowerCase().indexOf("connection: keep-alive")>0){
					//https tunnel
					try{
						long timeout=Config.getInt("tunnelIdle",120000);
						long timer=System.currentTimeMillis();
						Logger.log("keep-alive");
						while(true){
							len=0;
							if(pis.available()>0){
								len=pis.read(bb);
								cos.write(bb,0,len);
								cos.flush();
								Logger.log(bb,0,len);
							}
							if(cis.available()>0){
								len=cis.read(bb);
								pos.write(bb,0,len);
								pos.flush();
								Logger.log(bb,0,len);
							}
							if(len==0){
								Thread.yield();
								//if(!socket.isValid()||!parentSock.isValid())break;
								if(System.currentTimeMillis()-timer>timeout)break;
							}else{
								timer=System.currentTimeMillis();
							}
						}
					}catch (Exception e){
						Logger.log(e);
					}
				}else{
					//http
					//Receive & redirect response
					len=0;
					while(len>=0){
						try{
							len=pis.read(bb);
						}catch(Exception e){
							Logger.log(""+e);
							break;
						}
						Logger.log(bb,0,len);
						if(len>0)cos.write(bb,0,len);
					}
					cos.flush();
				}
			}
			//done?
		}catch(Exception e){
			Logger.log(e);
		}
		//close all sockets
		if(parentSock!=null){
			try{
				parentSock.close();
			}catch(Exception e){
				Logger.log(""+e);
			}
		}
		try{
			socket.close();
		}catch(Exception e){
			Logger.log(""+e);
		}
	}
	static String getCR(String s){
		int i=s.indexOf('\n');
		if(i>0){
			char c=s.charAt(i-1);
			if( c=='\r' )return "\r\n";
			return "\n";
		}
		return "\r\n";
	}
	String hideHost(String url)throws Exception{
		String ret=new String();
		int pos=url.indexOf("://");
		while(pos>=0){
			String host=url.substring(pos+3);
			for(int i=0;i<host.length();i++){
				if( "\\/@?#".indexOf(host.charAt(i)) >= 0 ){
					host=host.substring(0,i);
					break;
				}
			}
			ret+=url.substring(0,pos);
			url=url.substring(pos+3+host.length());
			
			InetAddress hostAddr = InetAddress.getByName(host);
			host=hostAddr.getHostAddress();
			ret+="://"+host;
			pos=url.indexOf("://",pos+1);
		}
		ret+=url;
		return ret;
	}
	
	//returns a new request
	String hideHost(String request,String method,String url,String CR){
		boolean urlHostHidden=false;
		String host;
		String referer;
		if(Server.logRealURL)Logger.log(socket.getInetAddress().getHostName(),method+" "+url,null);
		try{
			int pos=request.indexOf(url);
			String newUrl=hideHost(url);
			request=method+" "+newUrl+request.substring(pos+url.length());
			url=newUrl;
			if(Server.logHiddenURL)Logger.log(socket.getInetAddress().getHostName(),"$ "+method+" "+url,null);
			urlHostHidden=true;
		}catch(Exception e){
			Logger.log(e);
		}
		if(!urlHostHidden&&Server.logHiddenURL)
			Logger.log(socket.getInetAddress().getHostName(),"$ "+method+" "+url,null);
		try{
			int i=request.indexOf(CR+"Host:");
			if(i>=0){
				int i2=request.indexOf(CR,i+CR.length());
				if(i2>0){
					host=request.substring(i+5+CR.length(),i2).trim();
					Logger.log(".host="+host);
					host=InetAddress.getByName(host).getHostAddress();
					request=request.substring(0,i)+
						CR+"Host: "+host+
						request.substring(i2);
				}else{
					host=request.substring(i+5+CR.length()).trim();
					host=InetAddress.getByName(host).getHostAddress();
					request=request.substring(0,i)+
						CR+"Host: "+host;
				}
			}
		}catch(Exception e){
			Logger.log(e);
		}
		/*
		try{
			int i=request.indexOf(CR+"Referer:");
			if(i>=0){
				int i2=request.indexOf(CR,i+CR.length());
				if(i2>0){
					referer=request.substring(i+8+CR.length(),i2).trim();
					Logger.log(".referer="+referer);
					referer=hideHost(referer);
					request=request.substring(0,i)+
						CR+"Referer: "+referer+
						request.substring(i2);
				}else{
					referer=request.substring(i+8+CR.length()).trim();
					referer=hideHost(referer);
					request=request.substring(0,i)+
						CR+"Referer: "+referer;
				}
			}
		}catch(Exception e){
			Logger.log(e);
		}
		*/
		return request;
	}
}
