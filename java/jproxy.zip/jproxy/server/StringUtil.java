package server;

import java.util.StringTokenizer;

public class StringUtil{
	public static String getHead(String str,char delim){
		if(str==null)return null;
		int i=str.indexOf(delim);
		if ( i<0 )return str;
		if ( i==0 )return "";
		return str.substring(0,i);
	}
	public static String getHead(String str,String delim){
		if(str==null)return null;
		if ( delim==null || delim.length()==0 )return str;
		int i=str.indexOf(delim);
		if ( i<0 )return str;
		if ( i==0 )return "";
		return str.substring(0,i);
	}
	public static String getTail(String str,char delim){
		if(str==null)return null;
		int i=str.indexOf(delim);
		int l=str.length();
		if ( i<0 )return null;
		if ( i==l-1 )return null;
		return str.substring(i+1);
	}
	public static String getLastTail(String str,char delim){
		if(str==null)return null;
		int i=str.lastIndexOf(delim);
		int l=str.length();
		if ( i<0 )return null;
		if ( i==l-1 )return null;
		return str.substring(i+1);
	}
	public static String removeLastTail(String str,char delim){
		if(str==null)return null;
		int i=str.lastIndexOf(delim);
		int l=str.length();
		if ( i<0 )return str;
		return str.substring(0,i);

	}
	public static boolean match(String str,String mask){
		try{
			boolean asterisk=false;
			int pos=0;
			StringTokenizer st=new StringTokenizer(mask,"*",true);
			while (st.hasMoreTokens()){
				String s=st.nextToken();
				if(s.equals("*")){
					asterisk=true;
				}else{
					if(asterisk){
						pos=str.indexOf(s,pos);
						if(pos<0)return false;
					}else{
						if(!str.substring(pos,pos+s.length()).equals(s))return false;
					}
					pos+=s.length();
					asterisk=false;
				}
			}
			if(!asterisk && pos!=str.length())return false;
			return true;
		}catch (Exception e){
			return false;
		}
	}
}
