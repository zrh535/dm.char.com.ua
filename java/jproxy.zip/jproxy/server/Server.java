package server;

import java.net.ServerSocket;

public class Server{
	private static final String name="Java HTTP Redirector";
	protected static String parentAuthorizationString;
	protected static String parentHost;
	protected static int parentPort;
	protected static boolean logRequests;
	protected static boolean logRestricted;
	protected static boolean logHiddenURL;
	protected static boolean logRealURL;

	public static void start(String configFile){
		try{
			Config.load(configFile);
			if(Config.getBoolean("awtConsole"))new JLogWindow();
			Logger.init();
			Restrict.init();
			parentAuthorizationString=Config.getString("parentUser");
			if(parentAuthorizationString!=null){
				parentAuthorizationString+=":"+Config.getString("parentPass","");
				parentAuthorizationString="Basic "+Base64Encoder.toBase64String(parentAuthorizationString.getBytes());
			}
			logRequests=Config.getBoolean("logRequests");
			logRestricted=Config.getBoolean("logRestricted");
			logHiddenURL=Config.getBoolean("logHiddenURL");
			logRealURL=Config.getBoolean("logRealURL");
			
			parentHost=Config.getString("parentHost");
			if(parentHost==null)throw new Exception("parentHost parameter not defined.");
			parentPort=Config.getInt("parentPort",8080);
			Logger.log("Starting "+name+"...");
			Logger.log("parent="+parentHost+":"+parentPort);
			int port=Config.getInt("port",8080);
			Logger.log("port="+port);
			ServerSocket ssock=new ServerSocket(port);
			Logger.log("started on "+ssock.getInetAddress().getHostName()+":"+ssock.getLocalPort());
			while(true){
				new Thread(new RequestRunner(ssock.accept())).start();
			}
		}catch (Exception e){
			Logger.log(e);
		}
	}
	public static String getName(){
		return name;
	}
}
