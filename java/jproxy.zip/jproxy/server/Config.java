package server;

import java.io.IOException;
import java.io.FileInputStream;
import java.util.Properties;
import java.util.Enumeration;

public class Config{
	private static Properties prop=new Properties();

	private Config(){
	}

	public static String getString(String name,String def){
		return prop.getProperty(name,def);
	}
	public static String getString(String name){
		return prop.getProperty(name);
	}
	public static int getInt(String name,int def){
		String s=prop.getProperty(name, String.valueOf(def) );
		try{
			return Integer.parseInt( s );
		}catch(NumberFormatException e){
			return 0;
		}
	}
	public static int getInt(String name){
		return getInt(name,0);
	}
	public static boolean getBoolean(String name){
		String val=getString(name,"").toLowerCase();
		if(val.equals("1")||val.equals("true"))return true;
		return false;
	}
	public static Enumeration keys(){
		return prop.keys();
	}
	public static void load(String filename)throws IOException{
		FileInputStream fis=new FileInputStream(filename);
		prop.load(fis);
		fis.close();
	}
}
