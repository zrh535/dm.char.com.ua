package server;

import java.io.PrintStream;
import java.io.FileOutputStream;
import java.io.StringWriter;
import java.io.PrintWriter;
import java.util.Date;
import java.text.SimpleDateFormat;

public class Logger{
	private static PrintStream log=null;
	private static PrintStream accessLog=null;
	private static PrintStream stdLog=System.out;
	private static SimpleDateFormat timeFormat=new SimpleDateFormat("HH:mm:ss");
	private static SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd");
	private static String lastDate="";
	private static FileOutputStream dataLog=null;

	private Logger(){
	}

	public static void init()throws Exception{
		log=new PrintStream(new FileOutputStream("jproxy.log",Config.getBoolean("appendLog")));
		accessLog=new PrintStream(new FileOutputStream("access.log",Config.getBoolean("appendAccess")));
		if(Config.getBoolean("logData"))dataLog=new FileOutputStream("data.log",Config.getBoolean("appendData"));
	}

	private static void checkDate(Date d){
		synchronized(dateFormat){
			String s=dateFormat.format(d);
			if(!s.equals(lastDate)){
				lastDate=s;
				s="Date: "+lastDate;
				if(log!=null)log.println(s);
				if(accessLog!=null)accessLog.println(s);
				stdLog.println(s);
			}
		}
	}

	private static String getHead(){
		Date d=new Date();
		checkDate(d);
		return timeFormat.format(d)+" ";
	}
	public static synchronized void log(byte bb[]){
		log(bb,0,bb.length);
	}
	public static synchronized void log(byte bb[],int i,int l){
		try{
			if(dataLog!=null){
				String s="\r\n<<"+getHead()+">>\r\n";
				synchronized(dataLog){
					dataLog.write(bb,i,l);
					dataLog.write(s.getBytes());
				}
			}
		}catch(Exception e){
		}
	}
	public static void log(String msg){
		String s=getHead()+msg;
		stdLog.println(s);
		if(log!=null){
			synchronized(log){
				log.println(s);
			}
		}
	}
	public static void log(String host,String url,String userAgent){
		String s=getHead()+host+"\t"+url;
		if(userAgent!=null)s+="\t"+userAgent;
		stdLog.println(s);
		if(accessLog!=null){
			synchronized(accessLog){
				accessLog.println(s);
			}
		}
	}
	public static void log(Throwable t){
		StringWriter sw=new StringWriter();
		t.printStackTrace(new PrintWriter(sw));
		log("Exception:\n\t"+sw.toString());
	}
}