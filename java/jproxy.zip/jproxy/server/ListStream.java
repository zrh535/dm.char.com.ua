package server;

import java.io.OutputStream;
import java.awt.List;

public class ListStream extends OutputStream{
	List list;
	StringBuffer buff=new StringBuffer();
	public static final int TABSIZE=11;
	public ListStream(List list){
		super();
		this.list=list;
	}
    public void write(int b){
		byte bb[]=new byte[1];
		bb[0]=(byte)b;
		char c=(new String(bb)).charAt(0);
		if(c=='\r'||c=='\n'){
			flush();
		}else if(c=='\t'){
			int i=TABSIZE-(buff.length()-(buff.length()/TABSIZE)*TABSIZE);
			if ( i<=0 )i=TABSIZE;
			while(i>0){buff.append(' ');i--;}
		}else{
			buff.append(c);
		}
	}
    public void write(byte b[]){
		write(b, 0, b.length);
    }
    public void write(byte b[], int off, int len){
		for (int i = 0 ; i < len ; i++){
			write(b[off + i]);
		}
    }
    public void flush(){
		if(buff.length()>0){
			list.add(buff.toString());
			int i=list.getItemCount();
			list.select(i-1);
			if(i>500)list.remove(0);
			buff.setLength(0);
		}
    }
    public void close(){
    }
}
