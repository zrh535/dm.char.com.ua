package server;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;

public class JLogWindow extends WindowAdapter implements ActionListener{
	private Frame frame;
	private List log;
	private Button bClose;
	private Button bClear;
	public JLogWindow(){
		frame=new Frame(Server.getName());
		log=new List();
		bClose=new Button("Close");
		bClear=new Button("Clear");
		
		log.setFont(new Font("Monospaced", Font.PLAIN,12) );

		frame.addWindowListener(this); 
		bClose.addActionListener(this);
		bClear.addActionListener(this);

		Dimension dim=Toolkit.getDefaultToolkit().getScreenSize();
		
		frame.setSize(dim.width, dim.height-33);
		frame.setLayout(new BorderLayout());
		frame.add(log,BorderLayout.CENTER);

		Panel butPanel= new Panel(new BorderLayout());

		butPanel.add(bClose,BorderLayout.SOUTH);
		butPanel.add(bClear,BorderLayout.NORTH);

		frame.add(butPanel, BorderLayout.SOUTH);

		frame.show();
		System.setOut(new PrintStream(new ListStream(log)));
		System.setErr(System.out);
	}
	public void windowClosing(WindowEvent e) {
		e.getWindow().dispose();
	}
	public void windowClosed(WindowEvent e) {
		System.gc();
		System.exit(0);
	}
	public void actionPerformed(ActionEvent e){
		String cmd=e.getActionCommand();
		if(cmd.equals(bClose.getActionCommand())){
			frame.dispose();
		}else if(cmd.equals(bClear.getActionCommand())){
		      	log.removeAll();
		}
	}
}