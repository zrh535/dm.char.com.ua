package server;

import java.util.Vector;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

class Restrict{
	private static String restrict[];
	static void init() throws Exception{
		restrict=readRows("restrict.prop");
	}
	static boolean isRestricted(String str){
		String s=str.toLowerCase();
		for(int i=0;i<restrict.length;i++){
			if(StringUtil.match(s,restrict[i]))return true;
		}
		return false;
	}
	private static String[] readRows(String filename)throws Exception{
		BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream(filename)));
		Vector v=new Vector();
		String s;
		while((s=br.readLine())!=null){
			s=s.trim();
			if(s.length()==0)continue;
			if(s.charAt(0)=='#')continue;
			v.add(s);
		}
		String ss[]=new String[v.size()];
		for (int i=0;i<v.size();i++)ss[i]=(String)v.elementAt(i);
		return ss;
	}

}