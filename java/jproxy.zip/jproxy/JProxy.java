import server.Server;
import server.JLogWindow;

class JProxy{
	public static void main(String[] args){
		Server.start("JProxy.prop");
	}
}
