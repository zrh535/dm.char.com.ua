author: Dmitry Lukyanov  dlukyanov@ukr.net

This is a tiny http redirector :)

to make auto authentication for proxy server
and resticting bunners

specially for Taras Domansky
