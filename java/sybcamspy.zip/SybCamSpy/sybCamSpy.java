import java.util.*;
import java.net.*;
import java.io.*;

public class sybCamSpy
{
	public static void main(String[] args){
		new sybCamSpy().exec();
	}
	private String getExt(){
		String s=url.getFile();
		int i=s.lastIndexOf('.');
		if(i<0 || s.indexOf('/',i)>0 || s.indexOf('\\',i)>0)return ".";
		return s.substring(i);
	}
	private String getNewName(){
		String s=""+System.currentTimeMillis();
		return s.substring(0,s.length()-3)+ext;
	}
	private boolean compareFiles(String n1,String n2) throws IOException{
		int r=1;
		InputStream f1,f2;
		f1=new FileInputStream(n1);
		f2=new FileInputStream(n2);
		while(r>=0){
			r=f1.read();
			if(r!=f2.read())r=-2;
		}
		f1.close();
		f2.close();
		f1=null;
		f2=null;
		if(r==-1)System.out.println("nothing changed.");
		return r==-1;
	}
	private void exec(){
		try{

			System.out.println("Press Ctrl+C to interrupt");
			prop.load(new FileInputStream(this.getClass().getName()+".props"));
			
			System.out.println("properties loaded");
			url=new URL(prop.getProperty("url"));
			System.out.println("url="+url);
			ext=getExt();

			String s;
			s=prop.getProperty("http.proxyHost");
			if( s!=null && s.length()>0 ){
				System.setProperty("http.proxyHost",s);
				System.out.print("httpProxy="+s);
				s=prop.getProperty("http.proxyPort");
				if(s==null || s.length()==0 || Integer.parseInt(s)==0){
					s="80";
				}
				System.setProperty("http.proxyPort",s);
				System.out.println(":"+s);
			}


			timer=new Integer(prop.getProperty("timer")).longValue();
			System.out.println("timer="+timer+" sec.");
			if( timer > 86400 || timer < 1 )throw new Exception("timer is out of range: 1<=timer<=86400");
			dst=prop.getProperty("dst");
			if( dst==null || dst.length()==0 )dst="./";
			if( dst.charAt(dst.length()-1)!='/' && dst.charAt(dst.length()-1)!='\\' )dst+='/';
			System.out.println("dst="+dst);
			//all common properties are loaded. lets create lastfile props.
			prop=new Properties();
			try{
				prop.load(new FileInputStream(dst+"lastFile.props"));
				lastName=prop.getProperty("name");
				if (lastName!=null){
					if(lastName.length()==0){
						lastName=null;
					}else{
						if (!new File(dst+lastName).isFile())lastName=null;
					}
				}
				fCount=Integer.parseInt(prop.getProperty("count"));
				if(fCount<0)fCount=0;
			}catch(Exception e){
			}
			if(lastName!=null)System.out.println("last file="+lastName);
			if(fCount>0)System.out.println("files="+fCount);

			System.out.println("----=< loop start >=----");
			while (true){
				FileOutputStream fos;
				InputStream uis;
				System.out.print("downloading");
				uis=url.openStream();
				fos=new FileOutputStream(dst+tempName,false);
				int rd;
				int step=0;
				long sumrd=0;

				rd=uis.read(buf);
				while ( rd>0 ){
					sumrd+=rd;
					fos.write(buf,0,rd);
					if(step<sumrd/2048){
						step=(int)(sumrd/2048);
						System.out.print(".");
					}
					rd=uis.read(buf);
				}
				System.out.println(""+sumrd+"b");
				fos.close();
				uis.close();
				if ( lastName==null || !compareFiles(dst+tempName,dst+lastName) ){
					lastName=getNewName();
					System.out.println("new name="+lastName);
					if(!(new File(dst+tempName).renameTo(new File(dst+lastName))))throw new IOException("Can't rename file: "+dst+tempName+"\n\tto: "+dst+lastName);
					fCount++;
					System.out.println("files="+fCount);
					prop.put("name",lastName);
					prop.put("count",""+fCount);
					prop.store(new FileOutputStream(dst+"lastFile.props",false),this.getClass().getName()+" Last downloaded file name");
				}
				System.out.println("sleep...\n");
				Thread.sleep(timer*1000);
			}

		}catch (Exception e){
			System.out.println("\n"+e);
		}
	}
	//------------------------
	Properties prop=new Properties();
	URL url;
	long timer;
	int fCount=0;
	byte buf[]=new byte [1024];
	boolean err;
	String dst;
	String tempName="tmp";
	String lastName=null;
	String ext="";
}
