author: Dmitry Lukyanov  ldu@writeme.com

This is a tiny http server :)

to make search in JavaDoc generated documentation.
(supports docs only with several packages)

You can specify doc.roots in JDoc.prop

batches:
  svcInstall.bat     !!! specify correct path here !!!
  svcRemove.bat
  svcReStart.bat
  svcStart.bat
  svcStop.bat

are manage JDoc as windowz NT service


to start JDoc in console mode:

java JDoc


to start JDoc in windowed mode:

java JDoc w
or
javaw JDoc w
