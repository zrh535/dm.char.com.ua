import server.Server;
import server.JDocWindow;
import server.Logger;

class JDoc{
	public static void main(String[] args){
		System.setProperty("shutdown.method","shutDown");
		if(args.length>0&&args[0].equals("w"))new JDocWindow();
		Server.start("JDoc.prop");
	}
	public static void shutDown(){
		Logger.log("shut down.");
		System.gc();
		System.exit(0);
	}
}
