package server;

import java.util.Properties;

public class MimeTypes{
	protected static MimeTypes mime=new MimeTypes();

	protected Properties types;

	protected MimeTypes(){
		types=new Properties();
		types.setProperty("*"   ,"application/octet-stream");
		types.setProperty("txt" ,"text/plain");
		types.setProperty("rtf" ,"text/richtext");
		types.setProperty("htm" ,"text/html");
		types.setProperty("html","text/html");
		types.setProperty("stm" ,"text/html");
		types.setProperty("stml","text/html");
		types.setProperty("css" ,"text/css");
		types.setProperty("wav" ,"audio/wav");
		types.setProperty("gif" ,"image/gif");
		types.setProperty("jpeg","image/jpeg");
		types.setProperty("jpg" ,"image/jpeg");
		types.setProperty("tiff","image/tiff");
		types.setProperty("png" ,"image/x-png");
		types.setProperty("bmp" ,"image/bmp");
		types.setProperty("xbm" ,"image/xbm");
		types.setProperty("ico" ,"image/ico");
		types.setProperty("avi" ,"video/avi");
		types.setProperty("mpeg","video/mpeg");
	}
	public static String getExtType(String ext){
		if(ext!=null){
			String s=mime.types.getProperty(ext.toLowerCase());
			if(s!=null)return s;
		}
		return mime.types.getProperty("*");
	}
	public static String getFileType(String name){
		if(name==null)return null;
		return getExtType(StringUtil.getLastTail(name,'.'));
	}
}
