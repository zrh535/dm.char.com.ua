package server;

import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class HttpOutputStream extends OutputStream {
	protected OutputStream out;
	protected HttpResponse resp;
	private boolean transferStarted;

	public HttpOutputStream(OutputStream out,HttpResponse r){
		transferStarted=false;
		this.out=out;
		this.resp=r;
	}
	protected void checkStart() throws IOException{
		if(!transferStarted){
			transferStarted=true;
			out.write(resp.toString().getBytes());
		}
	}
	public void write(int b) throws IOException{
		checkStart();
		out.write(b);
	}

	public void write(byte b[]) throws IOException {
		checkStart();
		out.write(b);
	}

	public void write(byte b[], int off, int len) throws IOException {
		checkStart();
		out.write(b,off,len);
	}
	public void flush() throws IOException {
		out.flush();
	}

	public void close(){
	}
	public boolean isHeaderSent(){
		return transferStarted;
	}

}
