package server;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;

public class JDocWindow extends WindowAdapter implements ActionListener{
	private Frame frame;
	private List log;
	private Button bClose;
	public JDocWindow(){
		frame=new Frame(Server.getName());
		log=new List();
		bClose=new Button("Close");
		
		log.setFont(new Font("Monospaced", Font.PLAIN,12) );

	    frame.addWindowListener(this); 
		bClose.addActionListener(this);

	    frame.setSize(640, 440);
		frame.setLayout(new BorderLayout());
		frame.add(log,"Center");
		frame.add(bClose,"South");
		frame.show();
		System.setOut(new PrintStream(new ListStream(log)));
		System.setErr(System.out);
	}
	public void windowClosing(WindowEvent e) {
		e.getWindow().dispose();
	}
	public void windowClosed(WindowEvent e) {
		System.gc();
		System.exit(0);
	}
	public void actionPerformed(ActionEvent e){
		String cmd=e.getActionCommand();
		if(cmd.equals(bClose.getActionCommand())){
			frame.dispose();
		}
	}
}