package server;

import java.net.ServerSocket;

public class Server{
	private static final String name="JavaDoc Simple Server";
	private static Config config=null;

	public static void start(String configFile){
		try{
			config=new Config(configFile);
			config.load();
			Logger.log("Starting "+name+"...");
			int port=config.getInt("port",999);
			Logger.log("port="+port);
			ServerSocket ssock=new ServerSocket(port);
			Logger.log("started on "+ssock.getInetAddress().getHostName()+":"+ssock.getLocalPort());
			while(true){
				new Thread(new RequestRunner(ssock.accept())).start();
			}
		}catch (Exception e){
			Logger.log(e);
		}
	}
	public static String getName(){
		return name;
	}
	public static Config getConfig(){
		return config;
	}
}
