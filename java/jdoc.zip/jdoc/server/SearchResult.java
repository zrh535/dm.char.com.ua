package server;

import java.util.Properties;
import java.io.File;
import java.io.FileInputStream;

public class SearchResult {
	private String rootPath;
	private HttpRequest request;
	private StringBuffer out=new StringBuffer();
	private static String classInfoStr[] = {"<HR>","<HR>","<P>"};
	private static String packageInfoStr[] = {"<HR>","<H1>","</H2>"};

	public String get(HttpRequest r){
		this.rootPath=r.getRootPath();
		request=r;
		String search=request.getParm("search");
		String what=request.getParm("what");
		boolean matchcase=request.getParm("matchcase","").equals("checked");
		if(!matchcase)search=search.toLowerCase();
		try{
			if(search!=null&&search.length()>0&&what!=null){
				if(what.equals("1")){
					searchClass(new File(rootPath),search,matchcase);
				}else if(what.equals("2")){
					searchPackage(new File(rootPath),search,matchcase,true);
				}else{
					return "<p><b><font color='maroon' size='+2'>Wrong parameter what=\""+what+"\"</font></b><p>";
				}
			}else{
				return "<p><b><font color='maroon' size='+2'>SEARCH REQUEST IS EMPTY</font></b><p>";
			}
		}catch(Exception e){
			Logger.log(e);
			return "<p><b><font color='maroon' size='+2'>Exception occured:</font><br><font size='+1'>"+e+"</font><br></b>"+
			"<pre>INFO:\r\n"+
			"    path   = \""+rootPath+"\"\r\n"+
			"    rootID = \""+r.getRoot()+"\"\r\n"+
			"    URL    = \""+r.getURL()+"\"\r\n"+
			"</pre>";
		}
		if(out.length()>0)return out.toString();
		return "<p><b><font color='green' size='+2'>NO RESULTS for \""+search+"\"</font></b><p>";
	}
	private void searchPackage(File f,String search,boolean matchcase, boolean first)throws Exception{
		if(f.isFile()){
			return;
		}else if(f.isDirectory()){
			if(!first){
				String url=getRelativePath(f).replace('\\','/');
				if(url.charAt(url.length()-1)=='/')url=url.substring(0,url.length()-1);
				String uName=url.replace('/','.');
				if((matchcase&&uName.indexOf(search)>=0)||(!matchcase&&uName.toLowerCase().indexOf(search)>=0)){
					out.append("<DT><a href='/"+request.getRoot()+"/"+url+"/package-summary.html'>"+uName+"</a>");
					out.append("<DD>"+getPackageInfo(f));
				}
			}
			//----------------------------
			File ff[];
			int i;
			ff=f.listFiles(new DirFilter());
			for(i=0;i<ff.length;i++)searchPackage(ff[i],search,matchcase,false);
		}else{
			
		}
	}
	private void searchClass(File f,String search,boolean matchcase)throws Exception{
		if(f.isFile()){
			String name=f.getName();
			name=StringUtil.getHead(name,'.');
			if(!matchcase)name=name.toLowerCase();
			if( name.indexOf(search)>=0 ){
				String url=getRelativePath(f).replace('\\','/');
				String uName=StringUtil.removeLastTail(url,'.').replace('/','.');
				String s="<DT><a href='/"+request.getRoot()+"/"+url+"'>"+uName+"</a>"+"<DD>"+getClassInfo(f);
				if(name.equals(search))out.insert(0,s);else out.append(s);
			}
		}else if(f.isDirectory()){
			File ff[];
			int i;
			ff=f.listFiles(new DirFilter());
			for(i=0;i<ff.length;i++)searchClass(ff[i],search,matchcase);
			ff=f.listFiles(new HtmlFilter());
			for(i=0;i<ff.length;i++)searchClass(ff[i],search,matchcase);
		}else{
			
		}
	}
	private String getPackageInfo(File f)throws Exception{
		String text=null;
		String fail="Description not found :(";
		byte bb[]=new byte[4500];
		int len,i;
		f=new File(f,"package-summary.html");
		if(f.isFile()){
			FileInputStream in=new FileInputStream (f);
			len=in.read(bb);
			if(len>100){
				text=new String(bb,0,len);
				len=0;
				for(i=0;i<packageInfoStr.length;i++){
					len=text.indexOf(packageInfoStr[i])+packageInfoStr[i].length();
					if(len<0||len>=text.length())return fail;
				}
				i=text.indexOf('.',len);
				if(i>0){
					text=removeTags(text.substring(len,i));
				}else{
					text=removeTags(text.substring(len));
				}
			}
			in.close();
		}
		if(text==null)return fail;
		return text;
	}
	private String getClassInfo(File f)throws Exception{
		String text=null;
		String fail="Description not found :(";
		byte bb[]=new byte[6400];
		int len,i;
		FileInputStream in=new FileInputStream (f);
		len=in.read(bb);
		if(len>100){
			text=new String(bb,0,len);
			len=0;
			for(i=0;i<classInfoStr.length;i++){
				len=text.indexOf(classInfoStr[i],len);
				if(len<0||len>=text.length())return fail;
				len+=classInfoStr[i].length();
			}
			i=text.indexOf('.',len);
			if(i>0){
				text=removeTags(text.substring(len,i));
			}else{
				text=removeTags(text.substring(len));
			}
		}
		in.close();
		if(text==null)return fail;
		return text;
	}
	private String removeTags(String s){
		String out="";
		int j=0;
		int i;
		while(j>=0){
			i=s.indexOf('<',j);
			if(j>0)j++;
			if(i<0){
				out+=s.substring(j);
				break;
			}else{
				out+=s.substring(j,i)+" ";
			}
			j=s.indexOf('>',i);
		}
		return out;
	}
	

	private String getWebPath(File f)throws Exception{
		return "/"+request.getRoot()+"/"+getRelativePath(f);
	}
	private String getRelativePath(File f)throws Exception{
		String s=f.getPath();
		int len=rootPath.length();
		if(s.length()>len+1){
			return s.substring(len+1);
		}
		throw new Exception("Wrong path : \""+s+"\"  Root path= \""+rootPath+"\"");
	}
}
