package server;

import java.io.File;
import java.net.ProtocolException;
import java.util.Date;
import java.util.Hashtable;
import java.util.StringTokenizer;


public class Cookie{
	protected String  name=null;
	protected String  value=null;
	protected String  domain=null;
	protected String  path=null;
	protected Date    expires=null;
	protected boolean secure=false;
	private static final InetDateFormat dateFormatter = new InetDateFormat();

	protected void init(String name, String value, String domain, String path, Date expires, boolean secure){
		if (name == null)   throw new NullPointerException("missing name");
		if (value == null)  throw new NullPointerException("missing value");

		this.name    = name;
		this.value   = value;
		this.domain  = domain;
		this.path    = path==null?"/":path;
		this.expires = expires;
		this.secure  = secure;

		if (domain!=null&&this.domain.indexOf('.') == -1)  this.domain += ".local";
	}
	public Cookie(String name, String value, String domain, String path, Date expires, boolean secure){
		init(name, value, domain, path, expires, secure);
	}
	public Cookie(String name, String value, Date expires){
		init(name,value,null,null,expires,false);
	}
	public Cookie(String name, String value){
		init(name,value,null,null,null,false);
	}
	public static Cookie parseCookie(String cookieString){
		try{
			String  name=null;
			String  value=null;
			String  domain=null;
			String  path=null;
			Date    expires=null;
			boolean secure=false;
			String s,n,v;
			StringTokenizer st=new StringTokenizer(cookieString,";");
			if(st.hasMoreTokens()){
				s=st.nextToken().trim();
				name=StringUtil.getHead(s,'=').trim();
				value=StringUtil.getTail(s,'=').trim();
			}
			while(st.hasMoreTokens()){
				s=st.nextToken().trim();
				n=StringUtil.getHead(s,'=').trim().toLowerCase();
				v=StringUtil.getTail(s,'=').trim();
				if(n.equals("secure")){
					secure=true;
				}else if(s.equals("domain")){
					domain=v;
				}else if(s.equals("path")){
					path=v;
				}else if(s.equals("expires")){
					path=v;
				}
			}
			return new Cookie(name,value,domain,path,expires,secure);
		}catch(Exception e){
			return null;
		}
	}


	/**
	 * Return the name of this cookie.
	 */
	public String getName(){
		return name;
	}


	/**
	 * Return the value of this cookie.
	 */
	public String getValue(){
		return value;
	}


	/**
	 * @return the expiry date of this cookie, or null if none set.
	 */
	public Date expires(){
		return expires;
	}


	/**
	 * @return true if the cookie should be discarded at the end of the
	 *         session; false otherwise
	 */
	public boolean discard(){
		return (expires == null);
	}


	/**
	 * Return the domain this cookie is valid in.
	 */
	public String getDomain(){
		return domain;
	}


	/**
	 * Return the path this cookie is associated with.
	 */
	public String getPath(){
		return path;
	}


	/**
	 * Return whether this cookie should only be sent over secure connections.
	 */
	public boolean isSecure(){
		return secure;
	}


	/**
	 * @return true if this cookie has expired
	 */
	public boolean hasExpired(){
		return (expires != null  &&  expires.getTime() <= System.currentTimeMillis());
	}

	/**
	 * Hash up name, path and domain into new hash.
	 */
	public int hashCode(){
		int hc=name.hashCode();
		if(path!=null)hc+=path.hashCode();
		if(domain!=null)hc+=domain.hashCode();
		return hc;
	}


	/**
	 * Two cookies match if the name, path and domain match.
	 */
	public boolean equals(Object obj){
		if (obj == null) return false;
		if (!(obj instanceof Cookie))return false;
		Cookie other = (Cookie) obj;
		if((this.name==null||other.name==null)&&other.name!=this.name)return false;
		if((this.path==null||other.path==null)&&other.path!=this.path)return false;
		if((this.domain==null||other.domain==null)&&other.domain!=this.domain)return false;
		if(!this.name.equals(other.name))return false;
		if(!this.path.equals(other.path))return false;
		if(!this.domain.equals(other.domain))return false;
		return true;
	}


	/**
	 * Create a string containing all the cookie fields. The format is that
	 * used in the Set-Cookie header.
	 */
	public String toString(){
		String string = name + "=" + value;
		if (expires != null)  string += "; expires=" + dateFormatter.format(expires);
		if (path != null)     string += "; path=" + path;
		if (domain != null)   string += "; domain=" + domain;
		if (secure)           string += "; secure";
		return string;
	}
}

