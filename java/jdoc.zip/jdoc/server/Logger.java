package server;

import java.io.PrintStream;
import java.io.FileOutputStream;
import java.io.StringWriter;
import java.io.PrintWriter;
import java.util.Date;
import java.text.SimpleDateFormat;

public class Logger{
	private static Logger logger=new Logger();
	private PrintStream log;
	private PrintStream accessLog;
	private PrintStream stdLog;
	private SimpleDateFormat timeFormat;
	private SimpleDateFormat dateFormat;
	private String lastDate="";

	private Logger(){
		stdLog=System.out;
		timeFormat=new SimpleDateFormat("HH:mm:ss");
		dateFormat=new SimpleDateFormat("yyyy-MM-dd");
		try{
			log=new PrintStream(new FileOutputStream("jdoc.log",true));
		}catch(Exception e){
			e.printStackTrace(System.err);
		}
		try{
			accessLog=new PrintStream(new FileOutputStream("access.log",true));
		}catch(Exception e){
			e.printStackTrace(System.err);
		}
	}
	private void checkDate(Date d){
		synchronized(dateFormat){
			String s=dateFormat.format(d);
			if(!s.equals(lastDate)){
				lastDate=s;
				s="Date: "+lastDate;
				log.println(s);
				accessLog.println(s);
				stdLog.println(s);
			}
		}
	}

	private String getHead(Date d){
		return timeFormat.format(d)+" ";
	}

	public static void log(String msg){
		Date d=new Date();
		logger.checkDate(d);
		String s=logger.getHead(d)+msg;
		synchronized(logger.log){
			logger.stdLog.println(s);
			logger.log.println(s);
		}
	}
	public static void log(String host,String url,String userAgent){
		Date d=new Date();
		logger.checkDate(d);
		String s=logger.getHead(d)+host+"\t"+url;
		if(userAgent!=null)s+="\t"+userAgent;
		synchronized(logger.accessLog){
			logger.stdLog.println(s);
			logger.accessLog.println(s);
		}
	}
	public static void log(Throwable t){
		Date d=new Date();
		logger.checkDate(d);
		StringWriter sw=new StringWriter();
		t.printStackTrace(new PrintWriter(sw));
		String s=logger.getHead(d)+"Exception:\n\t"+sw.toString();
		synchronized(logger.log){
			logger.stdLog.println(s);
			logger.log.println(s);
		}
	}
}