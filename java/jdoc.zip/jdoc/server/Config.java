package server;

import java.io.IOException;
import java.io.FileInputStream;
import java.util.Properties;
import java.util.Enumeration;

public class Config{
	private Properties prop;
	private String filename;

	public Config(String filename)throws IOException{
		super();
		prop=new Properties();
		this.filename=filename;
	}

	public String getString(String name,String def){
		return prop.getProperty(name,def);
	}
	public String getString(String name){
		return prop.getProperty(name);
	}
	public int getInt(String name,int def){
		String s=prop.getProperty(name, String.valueOf(def) );
		try{
			return Integer.parseInt( s );
		}catch(NumberFormatException e){
			return 0;
		}
	}
	public int getInt(String name){
		return getInt(name,0);
	}
	public Enumeration keys(){
		return prop.keys();
	}
	public void load()throws IOException{
		FileInputStream fis=new FileInputStream(filename);
		prop.load(fis);
		fis.close();
	}
}
