package server;

import java.io.File;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.FileInputStream;

import java.util.Enumeration;
import java.util.StringTokenizer;

import java.net.URLEncoder;
import java.net.URLDecoder;

class JHelper{
	private String index="index.html";
	private String indexS="index.stml";
	private static final String iTag1="<%%";
	private static final String iTag2="%%>";
    private static final InetDateFormat dateFormatter = new InetDateFormat();


	public void go(HttpRequest req,HttpResponse resp)throws Exception{
		if(req.getRoot().length()==0&&req.getFile().equals("/")){
			resp.sendRedirect("/"+index);
		}else{
			sendFile(req,resp);
		}
	}
	/*****************************************/
	private void sendFile(HttpRequest req,HttpResponse resp)throws Exception{
		boolean dyna=false;
		String root=req.getRoot();
		String file=req.getFile();
		String path=req.getRootPath();
		if( path==null ){
			resp.sendError(HttpResponse.SC_NOT_FOUND,"Path not found:\n"+root+file+"\n\t"+path);
			return;
		}
		if( file.toLowerCase().equals("/"+index)&&root.length()>0 )file="/"+indexS;
		int i=file.length();
		if(i>5 && file.substring(i-5).toLowerCase().equals(".stml")){
			file=StringUtil.getLastTail(file,'/');
			path=Server.getConfig().getString("root","./root")+"/"+file;
			dyna=true;
		}else{
			path+=file;
		}

		if(!new File(path).isFile()){
			resp.sendError(HttpResponse.SC_NOT_FOUND,"Path not found:\n"+root+file+"\n\t"+path);
			return;
		}

		if(file.substring(1).toLowerCase().equals(index)&&root.length()==0||dyna){
			sendDynaFile(req,resp,path);
		}else{
			sendCommonFile(resp,path);
		}
	}

	private void sendCommonFile(HttpResponse resp,String path)throws Exception{
		OutputStream out=resp.getOutputStream();
		FileInputStream fis=new FileInputStream (path);
		resp.setContentTypeByFile(path);
		byte bb[]=new byte[4096];
		int len=0;
		while((len=fis.read(bb))>=0)if(len>0)out.write(bb,0,len);
		fis.close();
	}
	private void sendDynaFile(HttpRequest req,HttpResponse resp,String path)throws Exception{
		PrintWriter out=resp.getWriter();
		FileInputStream fis=new FileInputStream (path);
		String text=new String();
		byte bb[]=new byte[4096];
		int len=0;
		while((len=fis.read(bb))>=0)if(len>0)text+=new String(bb,0,len);
		fis.close();
		
		int it1,it2;
		it1=text.indexOf(iTag1);
		it2=text.indexOf(iTag2,it1);
		while(it1>=0&&it2>0){
			String tagName=text.substring(it1+iTag1.length(),it2);
			String s;
			if(tagName.equals("TITLE")){
				s=getRootName(req.getRoot());
			}else if(tagName.equals("ROOT")){
				s=req.getRoot();
			}else if(tagName.equals("LIST")){
				s=getDynaList();
			}else if(tagName.equals("HISTORY")){
				s=getHistory(req,resp);
			}else if(tagName.equals("RESULT")){
				s=new SearchResult().get(req);
			}else if(tagName.substring(0,5).equals("PARM:")){
				s=tagName.substring(5);
				int i=s.indexOf(':');
				if(i<0){
					s=req.getParm(s,"&lt;null&gt;");
				}else if(i==s.length()-1){
					s=req.getParm(s.substring(0,i),"");
				}else if( i>0 ){
					s=req.getParm(s.substring(0,i),s.substring(i+1));
				}else{
					s="<hr>wrong parameters for tag:<br>".concat(tagName).concat("<hr>");
				}
			}else{
				s="<font color='maroon' size='+1'><b>Unknown TAG:</b><hr>".concat(tagName).concat("</font><hr>");
			}
			text=text.substring(0,it1)+s+text.substring(it2+iTag2.length());
			it1=text.indexOf(iTag1);
			it2=text.indexOf(iTag2,it1);
		}
		out.print(text);
	}

	private String getDynaList(){
		String list=new String("");
		Enumeration en=Server.getConfig().keys();
		while(en.hasMoreElements()){
			String key=(String)en.nextElement();
			if(key.length()>4 && key.substring(0,4).equals("doc.")){
				String ID=key.substring(4);
				String name=getRootName(ID);
				list+="<li><a href='/"+ID+"/"+indexS+"'>"+name+"</a>\r\n";
			}
		}
		if(list.length()>0){
			list="<ul>\r\n"+list;
			list+="</ul>\r\n";
		}else{
			list="<font color='maroon' size='+1'><b>No registered documents!<br>Use <i>JDoc.prop</i> to specify Java documentation roots.</b></font>";
		}
		return list;
	}
	private String getHistory(HttpRequest req,HttpResponse resp){
		StringTokenizer st=new StringTokenizer (req.getCookieValue("history",""),">");
		String s="<option selected>&nbsp;";
		String cc=new String();
		String search=req.getParm("search");
		int i=0;

		if(search!=null){
			try{
				s+="<option>"+URLDecoder.decode(search);
				cc+=">"+URLEncoder.encode(search);
				i++;
			}catch(Exception e){
				Logger.log(e);
			}
		}
		while(st.hasMoreTokens()){
			search=st.nextToken();
			try{
				s+="<option>"+URLDecoder.decode(search);
				cc+=">"+URLEncoder.encode(search);
			}catch(Exception e){
				Logger.log(e);
			}
			i++;
			if(i>=10)break;
		}
		resp.addLongLifeCookie("history",cc);
		return s;
	}

	private String getRootName(String root){
		String notfound=" Not Found : ";
		String path=HttpRequest.getRootPath(root);
		if(path==null)return "Path"+notfound+path;
		path+="/"+index;
		if(new File(path).isFile()){
			try{
				FileInputStream in=new FileInputStream(path);
				byte bb[]=new byte[4096];
				int len;
				StringBuffer sb=new StringBuffer();
				while((len=in.read(bb))>=0){
					if(len>0)sb.append(new String(bb,0,len));
				}
				in.close();
				String s=sb.toString();
				sb=null;
				int i=s.indexOf("<TITLE>");
				if(i>=0){
					len=s.indexOf("</TITLE>",i);
					if(len>0){
						s=s.substring(i+7,len);
						return s;
					}
				}
			}catch(Exception e){
				return "getName Exception:"+e;
			}
		}else{
			return "File"+notfound+path;
		}
		return "Name"+notfound+path;
	}
}
