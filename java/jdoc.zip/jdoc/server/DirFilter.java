package server;

import java.io.FileFilter;
import java.io.File;

class DirFilter implements FileFilter{
	public boolean accept(File f){
		if(f!=null&&f.isDirectory()){
			String name=f.getName();
			if(name.equals("class-use")||name.equals("index-files")||name.indexOf('.')>=0)return false;
			return true;
		}
		return false;
	}
}
