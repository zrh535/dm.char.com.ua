package server;

import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.TimeZone;

class InetDateFormat extends SimpleDateFormat{
	public InetDateFormat(){
		super("EEE, dd-MMM-yyyy HH:mm:ss z", Locale.US);
		this.setTimeZone(TimeZone.getTimeZone("GMT"));
	}
}
