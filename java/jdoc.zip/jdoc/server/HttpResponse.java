package server;

import java.io.PrintWriter;
import java.io.OutputStream;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Date;
import java.net.Socket;
import java.util.Enumeration;

public class HttpResponse{
	//Declared Fields
	public static final int SC_INTERNAL_SERVER_ERROR=500;
	public static final int SC_MOVED_TEMPORARILY=302;
	public static final int SC_SEE_OTHER=303;
	public static final int SC_NOT_FOUND=404;
	public static final int SC_OK=200;
	public static final int SC_UNAUTHORIZED=401;
	public static final int SC_FORBIDDEN=403;

	private static final InetDateFormat dateFormatter = new InetDateFormat();
	private static final String CR="\r\n";

	private static String httpVer="HTTP/1.0";
	private int status;
	private String statusText;
	private Hashtable headers;
	private Socket socket;
	private String characterEncoding=null;
	private Hashtable cookies;
	private HttpOutputStream out=null;
	private PrintWriter pout=null;

	public HttpResponse(Socket socket){
		this.socket=socket;
		headers=new Hashtable();
		cookies=new Hashtable();
		setStatus(200);
		setContentTypeHtml();
		setHeader("Server",Server.getName());
	}

	public OutputStream getOutputStream() throws IOException{
		if(out==null)out=new HttpOutputStream(socket.getOutputStream(),this);
		return out;
	}
	public PrintWriter getWriter() throws IOException{
		if(pout==null)pout=new PrintWriter(getOutputStream());
		return pout;
	}


	public void addCookie(Cookie c){
		cookies.put(c.getName(),c);
	}
	public void addCookie(String name,String value){
		addCookie(new Cookie(name,value));
	}
	public void addCookie(String name,String value,Date date){
		addCookie(new Cookie(name,value,date));
	}
	public void addLongLifeCookie(String name,String value){
		addCookie(name,value,new Date(System.currentTimeMillis()+(long)1000*60*60*24*365) );
	}

	/**************************************************************/

	public void sendError(int error) throws IOException{
		sendError(error,null);
	}

	public void sendError(int error, String msg) throws IOException{
		setStatus(error);
		setContentTypeTxt();
		if(msg==null)msg=statusText;
		getWriter().println(msg);
	}

	public void sendRedirect(String url) throws IOException{
		setStatus(SC_MOVED_TEMPORARILY);
		setHeader("Location",url);
		setContentTypeTxt();
		getWriter().println("Document moved temporarily\n"+url);
	}


	public void setCharacterEncoding(String encoding){
		characterEncoding=encoding;
	}
	public String getCharacterEncoding(){
		return characterEncoding;
	}
	public void setContentLength(int len){
		setIntHeader("Content-Length",len);
	}
	public void setContentTypeTxt(){
		setContentType(MimeTypes.getExtType("txt"));
	}
	public void setContentTypeHtml(){
		setContentType(MimeTypes.getExtType("html"));
	}
	public void setContentTypeByFile(String name){
		setContentType(MimeTypes.getFileType(name));
	}
	public void setContentTypeByExt(String ext){
		setContentType(MimeTypes.getExtType(ext));
	}
	public void setContentType(String value){
		setHeader("Content-Type",value);
	}
	public boolean containsHeader(String name){
		return headers.containsKey(name);
	}
	public void setExpires(Date date){
		setDateHeader("Expires",date);
	}
	public void setDateHeader(Date date){
		setDateHeader("Date",date);
	}
	public void setDateHeader(String name, long date){
		setDateHeader(name,new Date(date));
	}
	public void setDateHeader(String name, Date date){
		setHeader(name,dateFormatter.format(date));
	}
	public void setIntHeader(String name, int value){
		setHeader(name,String.valueOf(value));
	}
	public void setHeader(String name, String value){
		headers.put(name,value);
	}

	public void setStatus(int status){
		String s;
		switch (status){
			case SC_INTERNAL_SERVER_ERROR:{
				s="Internal Server Error";
				break;
			}
			case SC_MOVED_TEMPORARILY:{
				s="Moved Temporarily";
				break;
			}
			case SC_SEE_OTHER:{
				s="Found";
				break;
			}
			case SC_NOT_FOUND:{
				s="Not Found";
				break;
			}
			case SC_OK:{
				s="OK";
				break;
			}
			case SC_UNAUTHORIZED:{
				s="Unauthorized";
				break;
			}
			case SC_FORBIDDEN:{
				s="Forbidden";
				break;
			}
			default :{
				s="Unknown";
				break;
			}
		}
		this.status=status;
		this.statusText=s;
	}
	public String toString(){
		StringBuffer sb=new StringBuffer();
		Enumeration en;
		sb.append(httpVer).append(' ').append(status).append(' ').append(statusText).append(CR);
		en=headers.keys();
		while(en.hasMoreElements()){
			String s=(String)en.nextElement();
			sb.append(s).append(": ").append((String)headers.get(s)).append(CR);
		}
		en=cookies.keys();
		while(en.hasMoreElements()){
			String s=(String)en.nextElement();
			Cookie c=(Cookie)cookies.get(s);
			sb.append("Set-Cookie: ").append(c.toString()).append(CR);
		}
		sb.append(CR);
		return sb.toString();
	}
	public void flush()throws IOException{
		if(pout!=null)pout.flush();
		if(out!=null)out.flush();
	}
}
