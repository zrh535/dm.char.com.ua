package server;

public class HtmlEncoder {

    /**
     * Translates a string into a HTML safe format.
     *
     * @param s the string to encode
     * @return the encoded string
     */
    public static String encode(String s) {
        StringBuffer encodedHtml = new StringBuffer();
        for (int i=0; i<s.length(); i++) {
	        char c=s.charAt(i);
            switch(c) {
            case '<':
                encodedHtml.append("&lt;");
                break;
            case '>':
                encodedHtml.append("&gt;");
                break;
            case '&':
                encodedHtml.append("&amp;");
                break;
            case '\'':
                encodedHtml.append("&#39;");
                break;
            case '"':
                encodedHtml.append("&quot;");
                break;
            case '\\':
                encodedHtml.append("&#92;");
                break;
            case (char)133:
                encodedHtml.append("&#133;");
                break;
            default:
                encodedHtml.append(i);
                break;
            }
        }
        return encodedHtml.toString();
    }
}
