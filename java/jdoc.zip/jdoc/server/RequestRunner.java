package server;

import java.io.InputStream;
import java.net.Socket;

class RequestRunner implements Runnable{
	private Socket socket;

	public RequestRunner(Socket socket){
		this.socket=socket;
	}
	public void run(){
		HttpRequest r;
		try{
			StringBuffer sb=new StringBuffer();
			boolean CR=false;
			char b;
			InputStream is=socket.getInputStream();
			while( (b=(char)is.read()) >=0){
				if(b=='\r')continue;
				if(b=='\n'&&CR)break;
				if(b=='\n'){
					CR=true;
				}else{
					CR=false;
				}
				sb.append(b);
			}
			HttpRequest req=new HttpRequest(sb.toString());
			HttpResponse resp=new HttpResponse(socket);
			//let's LOG
			if(!req.getFile().equals("/"))Logger.log(socket.getInetAddress().getHostName(),req.getURL(),req.getHeader("User-Agent"));
			//let's Help!
			new JHelper().go(req,resp);
			resp.flush();
		}catch(Exception e){
			Logger.log(e);
		}
		
		try{
			socket.close();
		}catch(Exception e){
			Logger.log(""+e);
		}
	}
}
