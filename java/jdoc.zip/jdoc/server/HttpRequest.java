package server;

import java.util.Hashtable;
import java.util.StringTokenizer;
import java.net.URLDecoder;

class HttpRequest{
	private String url;
	private String root;
	private String file;
	private Hashtable parms=new Hashtable();
	private Hashtable headers=new Hashtable();
	private Hashtable cookies=new Hashtable();

	public HttpRequest(String request)throws Exception{
		StringTokenizer st=new StringTokenizer (request, "\n");
		String s=st.nextToken();
		while(s.indexOf("GET")!=0)s=st.nextToken();
		parseHeaders(st);
		st=new StringTokenizer (s, " ");
		st.nextToken();
		url=st.nextToken();
		st=new StringTokenizer (url, "/");
		if(st.hasMoreTokens()){
			s=st.nextToken();
			int i=url.indexOf(s)+s.length();
			if(i<url.length()&&url.charAt(i)=='/'){
				root=s;
				s=url.substring(i);
			}else{
				root="";
				s=url;
			}
			int sharp=s.indexOf('#');
			int quest=s.indexOf('?');
			i=-1;
			if(sharp>-1)i=sharp;
			if(quest>-1 && (quest<i||i<0))i=quest;
			if(i>-1){
				file=s.substring(0,i);
			}else{
				file=s;
			}
			if(quest>-1){
				if(sharp>-1&&sharp>quest){
					s=s.substring(quest+1,sharp);
				}else{
					s=s.substring(quest+1);
				}
				parseParms(s,parms);
			}
			file=URLDecoder.decode(file);
		}else{
			file="/";
			root="";
		}
	}
	public String getURL(){
		return url;
	}
	public String getRoot(){
		return root;
	}
	public static String getRootPath(String root){
		String s;
		if ( root.length()==0 ){
			s=Server.getConfig().getString("root","./root");
		}else{
			s=Server.getConfig().getString("doc."+root);
		}
		return s;
	}
	public String getRootPath(){
		return getRootPath(root);
	}
	public String getFile(){
		return file;
	}
	public String getParm(String name,String defVal){
		if(parms.containsKey(name))return (String)parms.get(name);
		return defVal;
	}
	public String getParm(String name){
		return getParm(name,null);
	}
	public String getHeader(String name,String defVal){
		if(headers.containsKey(name))return (String)headers.get(name);
		return defVal;
	}
	public String getHeader(String name){
		return getHeader(name,null);
	}
	public Cookie getCookie(String name){
		return (Cookie)cookies.get(name);
	}
	public String getCookieValue(String name,String defVal){
		Cookie c=getCookie(name);
		if(c!=null)return c.getValue();
		return defVal;
	}
	public String getCookieValue(String name){
		return getCookieValue(name,null);
	}


	private void parseParms(String str,Hashtable ht) {
		String valArray[] = null;
		if (str == null) return;
		StringTokenizer st = new StringTokenizer(str, "&");

		while (st.hasMoreTokens()) {
			String s = st.nextToken();
			int pos = s.indexOf('=');
			if (pos<0||pos==s.length()-1)continue;
			String key = s.substring(0, pos);
			try{
				String val = URLDecoder.decode( s.substring(pos+1) );
				ht.put(key,val);
			}catch(Exception e){
				Logger.log(e);
			}
		}
    }
	private void parseHeaders(StringTokenizer st) {
		while (st.hasMoreTokens()) {
			String s = st.nextToken();
			int pos = s.indexOf(':');
			if (pos<1||pos==s.length()-1)continue;
			String name = s.substring(0, pos).trim();
			String val = s.substring(pos+1).trim();
			if(name.equals("Cookie")){
				parseCookies(val);
			}else{
				headers.put(name,val);
			}
		}
    }
	private void parseCookies(String s){
        Cookie cookie;
        // Cookies are separated by ';'
        StringTokenizer cookieTokens =new StringTokenizer(s, ";");
        while (cookieTokens.hasMoreTokens()) {
            // Name is separated from value by '='
            StringTokenizer t =new StringTokenizer(cookieTokens.nextToken(), "=");
            String name = t.nextToken().trim();
            if (t.hasMoreTokens()) {
                // Name has a value
                String value = t.nextToken().trim();
                cookies.put(name,new Cookie(name, value));
            }
        }
	}
}
