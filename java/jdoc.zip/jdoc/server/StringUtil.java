package server;

public class StringUtil{
	public static String getHead(String str,char delim){
		if(str==null)return null;
		int i=str.indexOf(delim);
		if ( i<0 )return str;
		if ( i==0 )return null;
		return str.substring(0,i);
	}
	public static String getTail(String str,char delim){
		if(str==null)return null;
		int i=str.indexOf(delim);
		int l=str.length();
		if ( i<0 )return null;
		if ( i==l-1 )return null;
		return str.substring(i+1);
	}
	public static String getLastTail(String str,char delim){
		if(str==null)return null;
		int i=str.lastIndexOf(delim);
		int l=str.length();
		if ( i<0 )return null;
		if ( i==l-1 )return null;
		return str.substring(i+1);
	}
	public static String removeLastTail(String str,char delim){
		if(str==null)return null;
		int i=str.lastIndexOf(delim);
		int l=str.length();
		if ( i<0 )return str;
		return str.substring(0,i);

	}
}
