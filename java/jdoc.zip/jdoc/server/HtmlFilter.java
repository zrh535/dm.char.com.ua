package server;

import java.io.FileFilter;
import java.io.File;

class HtmlFilter implements FileFilter{
	public boolean accept(File f){
		if(f!=null&&f.isFile()){
			String fn=f.getName();
			String s=StringUtil.getLastTail(fn,'.');
			if(s!=null){
				s=s.toLowerCase();
				if((s.equals("html")||s.equals("htm"))&&Character.isUpperCase(fn.charAt(0)))
					return true;
			}
		}
		return false;
	}
}
